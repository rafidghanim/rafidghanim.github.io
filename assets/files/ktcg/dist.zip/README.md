# Solve Chall Ini Plis [174 pts]

**Category:** [ PWN ]
**Solves:** 20

## Description
>Sebuah program sederhana tampak berjalan normal tanpa hal mencurigakan.  \r\n\r\nNamun di baliknya, terdapat mekanisme input yang menangani data tanpa batasan yang aman.  \r\n\r\nJika memori dapat dikendalikan dengan tepat, mungkin alur eksekusi program bisa diarahkan ke sesuatu yang seharusnya tidak pernah dijalankan.\r\n\r\n> \xf0\x9f\x96\xa5\xef\xb8\x8f Server : `nc 20.229.160.60 2268`\r\n\r\n> FORMAT : `KTCG{...}`  \r\n> Author : `kep_py`

**Hint**
* -

## Solution

### Flag

