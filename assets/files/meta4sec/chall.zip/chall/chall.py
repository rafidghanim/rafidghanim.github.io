from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP
from Crypto.Random import get_random_bytes
from Crypto.Util.number import getPrime, inverse, bytes_to_long, long_to_bytes, isPrime
from sympy import nextprime
import base64


def generate_large_prime_product():
    p = getPrime(512)
    n = 1
    phi = 1
    primes = []

    while True:
        primes.append(p)
        n *= p
        phi *= (p - 1)
        if n.bit_length() >= 8192:
            break
        p = nextprime(nextprime(p))

    return n, primes, phi, p


def get_valid_prime_update(n):
    update_n = nextprime(n)
    return update_n


def generate_rsa_keys(p, e=65537):
    q = getPrime(16)
    n = p * q
    phi = (p - 1) * (q - 1)
    d = inverse(e, phi)
    private_key = RSA.construct((n, e, d, p, q))
    public_key = private_key.publickey()
    return private_key, public_key


def encrypt_chunks(data, public_key):
    cipher_encrypt = PKCS1_OAEP.new(public_key)
    key_size = public_key.size_in_bytes()
    max_chunk_size = key_size - 42
    chunks = [data[i:i + max_chunk_size] for i in range(0, len(data), max_chunk_size)]
    encrypted_chunks = [cipher_encrypt.encrypt(chunk) for chunk in chunks]
    return encrypted_chunks


def decrypt_chunks(encrypted_chunks, private_key):
    cipher_decrypt = PKCS1_OAEP.new(private_key)
    decrypted_chunks = [cipher_decrypt.decrypt(chunk) for chunk in encrypted_chunks]
    return b''.join(decrypted_chunks)


def save_keys_and_cipher(public_key, private_key, encrypted_chunks):
    with open('public.pem', 'wb') as f:
        f.write(public_key.export_key(format='PEM'))

    with open('private.pem', 'wb') as f:
        f.write(private_key.export_key(format='PEM'))

    with open('encrypted', 'wb') as f:
        f.write(b''.join(encrypted_chunks))


def g_a_s(ct):
    while True:
        n, primes, phi, p = generate_large_prime_product()
        p = get_valid_prime_update(n)
        if p is None:
            continue
        break
    
    ct = pow(ct,65537,n)
    private_key, public_key = generate_rsa_keys(p)
    data = long_to_bytes(ct)
    encrypted_chunks = encrypt_chunks(data, public_key)
    decrypted_data = decrypt_chunks(encrypted_chunks, private_key)
    recovered_ct = bytes_to_long(decrypted_data)
    assert ct == recovered_ct
    save_keys_and_cipher(public_key, private_key, encrypted_chunks)


def main():
    ct = bytes_to_long(b'Meta4Sec{redacted}')
    g_a_s(ct)


if __name__ == "__main__":
    main()
