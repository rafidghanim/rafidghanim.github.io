mysterious message has been intercepted. Our analysts believe it was encrypted using a strange variation of a classic cipher.

Fortunately, we were able to recover a sample of the encryption in action: a plaintext message and its corresponding ciphertext. We believe the same method was used to encrypt the flag.

Your task is to:
1. Analyze the encoding pattern from the known input and output.
2. Decrypt the encrypted flag to reveal the original message.

===[ Files ]===

- test.txt        # known plaintext
- output_test.txt         # ciphertext of the known plaintext
- flag.txt      # encrypted flag (ciphertext to be decoded)

===[ Objective ]===

Recover the original flag from `flag.txt`.

Flag format: `Meta4Sec{...}`

Brute force isn't necessary to solve this challenge, but you're free to try. A logical approach and understanding of classical ciphers will take you further.

Good luck!